function addToCart(productId) {
  alert("Product " + productId + " added to cart!");
}